#!/usr/bin/env python
"""End-to-end smoke test on synthetic ODIR-like data (CPU, a few minutes).

  python tests/smoke_test.py --work /tmp/retina_smoke
It checks that data prep, every head type, KD, external evaluation and the tables run.
It does not measure accuracy.
"""
import argparse
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
PY = sys.executable


def run(cmd):
    print("$", " ".join(str(c) for c in cmd))
    subprocess.run([str(c) for c in cmd], check=True, cwd=ROOT)


def make_fake_odir(work, n_pat=80):
    rng = np.random.default_rng(0)
    img_dir = work / "odir_images"
    img_dir.mkdir(parents=True, exist_ok=True)
    kws = [("normal fundus", "N"), ("diabetic retinopathy", "D"), ("glaucoma", "G"), ("cataract", "C"),
           ("age-related macular degeneration", "A"), ("hypertensive retinopathy", "H"),
           ("pathological myopia", "M"), ("drusen", "O")]
    rows = []
    for pid in range(n_pat):
        r = {"ID": pid, "Patient Age": 50, "Patient Sex": "Female"}
        labs = set()
        for eye in ("Left", "Right"):
            k, l = kws[int(rng.choice(8, p=[.35, .15, .08, .08, .08, .06, .1, .1]))]
            fn = f"{pid}_{eye.lower()}.jpg"
            im = Image.new("RGB", (160, 130), (0, 0, 0))
            d = ImageDraw.Draw(im)
            c = tuple(int(v) for v in rng.integers(80, 200, 3))
            d.ellipse((10, 5, 150, 125), fill=c)
            for _ in range(5):
                x, y = rng.integers(30, 130), rng.integers(20, 110)
                d.ellipse((x, y, x + 8, y + 8), fill=tuple(int(v) for v in rng.integers(0, 255, 3)))
            im.save(img_dir / fn)
            r[f"{eye}-Fundus"] = fn
            r[f"{eye}-Diagnostic Keywords"] = k
            labs.add(l)
        for L in "NDGCAHMO":
            r[L] = int(L in labs)
        rows.append(r)
    ann = work / "annotations.csv"
    pd.DataFrame(rows).to_csv(ann, index=False)
    return ann, img_dir


def make_fake_rfmid(work, n=60):
    rng = np.random.default_rng(1)
    d = work / "rfmid_images"
    d.mkdir(parents=True, exist_ok=True)
    rows = []
    for i in range(1, n + 1):
        im = Image.new("RGB", (150, 120), (0, 0, 0))
        ImageDraw.Draw(im).ellipse((5, 5, 145, 115), fill=tuple(int(v) for v in rng.integers(60, 220, 3)))
        im.save(d / f"{i}.png")
        dr, armd, mya = (int(rng.random() < .2) for _ in range(3))
        rows.append({"ID": i, "Disease_Risk": int(dr or armd or mya), "DR": dr, "ARMD": armd, "MYA": mya})
    csv = work / "rfmid.csv"
    pd.DataFrame(rows).to_csv(csv, index=False)
    return csv, d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--work", default="/tmp/retina_smoke")
    a = ap.parse_args()
    work = Path(a.work)
    work.mkdir(parents=True, exist_ok=True)
    ann, img_dir = make_fake_odir(work)
    run([PY, "data_prep/01_audit_odir.py", "--ann", ann, "--img_dir", img_dir, "--out", work / "audit"])
    run([PY, "data_prep/02_make_splits.py", "--eye_table", work / "audit/eye_table.csv",
         "--out", work / "splits", "--drop_missing"])
    run([PY, "data_prep/03_cache_images.py", "--splits", work / "splits", "--out", work / "cache", "--res", 96])

    common = ["data.splits_dir=" + str(work / "splits"), "data.res=64", "data.batch_size=16",
              "data.num_workers=0", "optim.epochs=2", "optim.warmup_epochs=1", "optim.patience=5",
              "model.pretrained=false", "model.name=resnet18", "output_dir=" + str(work / "runs"),
              "device=cpu"]
    # teachers (flat and cascade), then students incl. KD
    run([PY, "scripts/train.py", "--set", *common, "run_name=t_flat", "model.head.type=flat"])
    run([PY, "scripts/train.py", "--set", *common, "run_name=t_casc", "model.head.type=cascade",
         "model.head.grouped=true", "model.head.cross_head=true", "loss.type=asl"])
    run([PY, "scripts/train.py", "--set", *common, "run_name=s_flat_kd", "model.name=resnet18",
         "model.head.type=flat", "kd.enabled=true", f"kd.teacher_run={work / 'runs/t_flat'}",
         "loss.type=db", "eval.eval_test=true"])
    run([PY, "scripts/train.py", "--set", *common, "run_name=s_casc_kd_cbam", "model.head.type=cascade",
         "model.head.cbam=true", "kd.enabled=true", f"kd.teacher_run={work / 'runs/t_casc'}",
         "loss.type=asl", "loss.label_smoothing=0.1", "data.sampler=rarest_inv", "eval.eval_test=true"])
    run([PY, "scripts/train.py", "--set", *common, "run_name=s_casc_ungrouped", "model.head.type=cascade",
         "model.head.grouped=false", "eval.eval_test=true"])

    csv, rimg = make_fake_rfmid(work)
    run([PY, "scripts/run_external.py", "--run", work / "runs/s_casc_kd_cbam", "--csv", csv,
         "--img_root", rimg, "--mapping", "configs/rfmid_mapping.yaml", "--res", 64])
    run([PY, "scripts/make_tables.py", "--runs", work / "runs", "--out", work / "tables",
         "--pair", "s_casc_kd_cbam", "s_casc_ungrouped"])
    run([PY, "scripts/explain.py", "--run", work / "runs/s_casc_kd_cbam", "--split", "test",
         "--n", 2, "--out", work / "explain", "--seed", 0])
    print("SMOKE TEST PASSED")


if __name__ == "__main__":
    main()
