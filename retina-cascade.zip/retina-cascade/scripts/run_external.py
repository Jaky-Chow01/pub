#!/usr/bin/env python
"""Zero-shot external validation (e.g. RFMiD) with thresholds frozen on ODIR validation data.

  python scripts/run_external.py --run runs/<run> --csv Train.csv Eval.csv Test.csv \
      --img_root RFMiD/images --mapping configs/rfmid_mapping.yaml --res 224
"""
import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from retina import LABELS, metrics as M  # noqa: E402
from retina.datasets import FundusDataset  # noqa: E402
from retina.engine import load_run, pick_device, predict, preds_frame, rule_for  # noqa: E402
from retina.utils import load_json, load_yaml, save_json  # noqa: E402

EXT = (".png", ".jpg", ".jpeg", ".tif", ".tiff")


def build_table(csvs, img_root, mapping):
    idc = mapping.get("id_column", "ID")
    df = pd.concat([pd.read_csv(c) for c in csvs], ignore_index=True)
    df.columns = [c.strip() for c in df.columns]
    index = {}
    for p in Path(img_root).rglob("*"):
        if p.suffix.lower() in EXT:
            index.setdefault(p.stem, str(p))
    df["path"] = df[idc].astype(str).map(index)
    missing = int(df["path"].isna().sum())
    df = df[df["path"].notna()].reset_index(drop=True)
    df["patient_id"] = df[idc].astype(str)
    df["filename"] = df[idc].astype(str)
    df["eye"] = "unknown"
    mapped = []
    gate_col = mapping.get("gate_column")
    for l in LABELS:
        df[f"y_{l}"] = np.nan
    if gate_col and gate_col in df.columns:
        df["y_N"] = 1 - (df[gate_col] > 0).astype(int)
        mapped.append("N")
    for l, cols in mapping.get("labels", {}).items():
        cols = [c for c in (cols or []) if c in df.columns]
        if cols:
            df[f"y_{l}"] = (df[cols].fillna(0).max(axis=1) > 0).astype(int)
            mapped.append(l)
    return df, mapped, missing


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--csv", nargs="+", required=True)
    ap.add_argument("--img_root", required=True)
    ap.add_argument("--mapping", default="configs/rfmid_mapping.yaml")
    ap.add_argument("--res", type=int, default=None)
    ap.add_argument("--name", default="rfmid")
    ap.add_argument("--ci", type=int, default=1000)
    a = ap.parse_args()

    device = pick_device({"device": "auto"})
    model, cfg = load_run(a.run, device)
    res = a.res or cfg["data"].get("res", 224)
    th = load_json(Path(a.run) / "thresholds.json")
    thr = np.array([th["thresholds"][l] for l in LABELS])
    tau_g = th["gate_tau"]

    mapping = load_yaml(a.mapping)
    df, mapped, missing = build_table(a.csv, a.img_root, mapping)
    print(f"{len(df)} images ({missing} listed but not found); labels evaluated: {mapped}")
    ds = FundusDataset(df, res, train=False)  # crops black border on load
    loader = DataLoader(ds, batch_size=32, shuffle=False, num_workers=0)
    pred = predict(model, loader, device, cfg["optim"].get("amp", True), res=res)

    out = Path(a.run) / f"external_{a.name}"
    out.mkdir(exist_ok=True)
    preds_frame(df, pred).to_csv(out / "preds.csv", index=False)
    pids = df.iloc[pred["idx"]]["patient_id"].to_numpy()
    rep = M.full_report(pred["y"].astype(int), pred["s"], pred["g"], thr, tau_g, rule_for(model.head_type),
                        patient_ids=pids, ci_B=a.ci, labels_mask=mapped)
    if "N" not in mapped:
        for k in [k for k in rep if k.startswith("gate_")]:
            rep.pop(k)
    rep["labels_evaluated"] = mapped
    rep["note"] = "zero-shot; thresholds frozen on ODIR validation; only mapped labels are evaluated"
    save_json(rep, out / "metrics.json")
    print({k: rep[k] for k in ("n_images", "macro_auc", "macro_ap") if k in rep}, rep.get("auc"))


if __name__ == "__main__":
    main()
