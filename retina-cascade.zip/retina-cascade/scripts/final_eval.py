#!/usr/bin/env python
"""Evaluate finished runs on the test split with thresholds frozen on validation data.
Use once per final configuration.

  python scripts/final_eval.py --runs runs/abl/abl_A8_s42 runs/abl/abl_A5_s42
"""
import argparse
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from retina import LABELS  # noqa: E402
from retina.engine import evaluate_test, load_run, pick_device  # noqa: E402
from retina.utils import load_json  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", nargs="+", required=True)
    ap.add_argument("--ci", type=int, default=1000)
    a = ap.parse_args()
    device = pick_device({"device": "auto"})
    for r in a.runs:
        model, cfg = load_run(r, device)
        th = load_json(Path(r) / "thresholds.json")
        thr = np.array([th["thresholds"][l] for l in LABELS])
        rep = evaluate_test(r, cfg, model, device, thr, th["gate_tau"], ci_B=a.ci)
        print(r, "test macro AUC", round(rep["macro_auc"], 4), rep["macro_auc_ci95"])


if __name__ == "__main__":
    main()
