#!/usr/bin/env python
"""Phase A: backbone sweep and teacher / student selection (validation data only).

  python scripts/run_sweep.py --set data.splits_dir=splits output_dir=runs/sweep
  python scripts/run_sweep.py --shard 0/4 ...        # run a quarter of the jobs on this GPU
  python scripts/run_sweep.py --select_only          # rank finished runs and write selection.json
"""
import argparse
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from retina.engine import train  # noqa: E402
from retina.utils import deep_update, load_config, load_json, load_yaml, parse_overrides, save_json, slug  # noqa: E402


def jobs_from(sweep, base, only):
    jobs = []
    for res in sweep.get("resolutions", [224]):
        for m in sweep["models"]:
            tag = m.get("tag", m["name"])
            if only and tag not in only and m["name"] not in only:
                continue
            for lr in m["lrs"]:
                over = deep_update({"model": {"name": m["name"], "head": {"type": "flat"}},
                                    "data": {"res": res}, "optim": {"lr": lr},
                                    "loss": {"type": "bce"}, "kd": {"enabled": False},
                                    "run_name": slug(f"sweep_{tag}_r{res}_lr{lr}")}, m.get("overrides"))
                jobs.append((tag, res, lr, deep_update(base, over)))
    return jobs


def select(out_dir, sweep):
    rows = []
    for d in Path(out_dir).glob("sweep_*"):
        if not (d / "val_metrics.json").exists():
            continue
        v, e = load_json(d / "val_metrics.json"), load_json(d / "efficiency.json")
        c = load_yaml(d / "config.yaml")
        rows.append({"run": d.name, "model": c["model"]["name"], "res": c["data"]["res"],
                     "lr": c["optim"]["lr"], "val_macro_auc": v["macro_auc"], "val_macro_ap": v["macro_ap"],
                     "params_m": e["params_m"], "gmacs": e["gmacs"], "latency_ms": e["latency_ms_bs1"]})
    if not rows:
        print("no finished sweep runs found")
        return
    df = pd.DataFrame(rows).sort_values("val_macro_auc", ascending=False)
    df.to_csv(Path(out_dir) / "sweep_all_runs.csv", index=False)
    best = df.sort_values(["val_macro_auc", "val_macro_ap", "params_m"], ascending=[False, False, True]) \
            .groupby(["model", "res"], as_index=False).first() \
            .sort_values(["val_macro_auc", "val_macro_ap", "params_m"], ascending=[False, False, True])
    best.to_csv(Path(out_dir) / "sweep_summary.csv", index=False)
    b = sweep.get("budget", {})
    ok = best[(best["params_m"] <= b.get("max_params_m", 1e9)) & (best["gmacs"] <= b.get("max_gmacs", 1e9))]
    sel = {"teacher": best.iloc[0].to_dict(),
           "student": ok.iloc[0].to_dict() if len(ok) else None,
           "student_budget": b,
           "top5_for_resolution_phase": best.head(5)["run"].tolist(),
           "gap_val_macro_auc": (float(best.iloc[0]["val_macro_auc"] - ok.iloc[0]["val_macro_auc"])
                                 if len(ok) else None)}
    save_json(sel, Path(out_dir) / "selection.json")
    print(best.round(4).to_string(index=False))
    print("\nteacher:", sel["teacher"]["run"], "| student:", sel["student"]["run"] if sel["student"] else None)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="configs/base.yaml")
    ap.add_argument("--sweep", default="configs/sweep.yaml")
    ap.add_argument("--set", nargs="*", default=[])
    ap.add_argument("--only", nargs="*", default=None, help="model names or tags")
    ap.add_argument("--shard", default="0/1")
    ap.add_argument("--dry_run", action="store_true")
    ap.add_argument("--select_only", action="store_true")
    a = ap.parse_args()
    base = load_config(a.base, parse_overrides(a.set))
    sweep = load_yaml(a.sweep)
    out_dir = base.get("output_dir", "runs")
    if not a.select_only:
        i, n = map(int, a.shard.split("/"))
        jobs = jobs_from(sweep, base, a.only)[i::n]
        for tag, res, lr, cfg in jobs:
            name = cfg["run_name"]
            pth = cfg["model"].get("pretrained_path")
            if pth and not Path(pth).exists():
                print(f"[skip] {name}: checkpoint {pth} not found")
                continue
            if (Path(out_dir) / name / "val_metrics.json").exists():
                print(f"[done] {name}")
                continue
            print(f"[job] {name}")
            if not a.dry_run:
                try:
                    train(cfg)
                except Exception as e:  # keep the sweep going
                    print(f"[fail] {name}: {e}")
    if not a.dry_run:
        select(out_dir, sweep)


if __name__ == "__main__":
    main()
