#!/usr/bin/env python
"""Aggregate run folders into tables and paired comparisons.

  python scripts/make_tables.py --runs runs --out tables --pair A8 A5 --pair A6 A1
Pairs use test_preds.csv of two runs (same test images) and report paired bootstrap and DeLong.
"""
import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from retina import LABELS, metrics as M  # noqa: E402
from retina.utils import load_json, save_json  # noqa: E402


def collect(runs):
    rows = []
    for d in sorted(Path(runs).iterdir()):
        if not (d / "val_metrics.json").exists():
            continue
        v = load_json(d / "val_metrics.json")
        e = load_json(d / "efficiency.json") if (d / "efficiency.json").exists() else {}
        r = {"run": d.name, "params_m": e.get("params_m"), "gflops": e.get("gflops"),
             "latency_ms": e.get("latency_ms_bs1"), "val_macro_auc": v["macro_auc"],
             "val_macro_ap": v["macro_ap"], "val_gate_auc": v.get("gate_auc"),
             "best_epoch": v.get("best_epoch")}
        if (d / "test_metrics.json").exists():
            t = load_json(d / "test_metrics.json")
            r.update({"test_macro_auc": t["macro_auc"], "test_macro_auc_no_O": t["macro_auc_no_O"],
                      "test_macro_ap": t["macro_ap"], "test_macro_f1": t["macro_f1"],
                      "test_macro_mcc": t["macro_mcc"], "test_macro_ece": t["macro_ece"],
                      "test_gate_auc": t.get("gate_auc"), "test_gate_sens": t.get("gate_sensitivity"),
                      "test_gate_spec": t.get("gate_specificity"),
                      "test_auc_ci_lo": t.get("macro_auc_ci95", [None, None])[0],
                      "test_auc_ci_hi": t.get("macro_auc_ci95", [None, None])[1]})
            for l in LABELS:
                r[f"test_auc_{l}"] = t["auc"][l]
        rows.append(r)
    return pd.DataFrame(rows)


def compare(runs, a, b, B=2000):
    pa = pd.read_csv(Path(runs) / a / "test_preds.csv")
    pb = pd.read_csv(Path(runs) / b / "test_preds.csv")
    assert (pa["filename"].values == pb["filename"].values).all(), "runs must share the same test images"
    y = pa[[f"y_{l}" for l in LABELS]].to_numpy().astype(int)
    sa = pa[[f"s_{l}" for l in LABELS]].to_numpy()
    sb = pb[[f"s_{l}" for l in LABELS]].to_numpy()
    pid = pa["patient_id"].to_numpy()
    out = {"a": a, "b": b,
           "macro_auc": M.paired_bootstrap(lambda i: M.macro_auc(y[i], sa[i]), lambda i: M.macro_auc(y[i], sb[i]), pid, B),
           "per_label_delong": {}}
    for j, l in enumerate(LABELS):
        if 0 < y[:, j].sum() < len(y):
            auc_a, auc_b, p = M.delong_test(y[:, j], sa[:, j], sb[:, j])
            out["per_label_delong"][l] = {"auc_a": auc_a, "auc_b": auc_b, "p": p}
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", default="runs")
    ap.add_argument("--out", default="tables")
    ap.add_argument("--pair", nargs=2, action="append", default=[])
    ap.add_argument("--B", type=int, default=2000)
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    df = collect(a.runs)
    df.to_csv(out / "runs_summary.csv", index=False)
    try:
        (out / "runs_summary.md").write_text(df.round(4).to_markdown(index=False))
    except ImportError:
        (out / "runs_summary.md").write_text(df.round(4).to_string(index=False))
    print(df.round(4).to_string(index=False))
    comps = [compare(a.runs, x, y, a.B) for x, y in a.pair]
    if comps:
        save_json(comps, out / "paired_comparisons.json")
        for c in comps:
            print(f"{c['a']} vs {c['b']}: macro AUC diff {c['macro_auc']['mean']:.4f} "
                  f"CI {c['macro_auc']['ci']}")


if __name__ == "__main__":
    main()
