#!/usr/bin/env python
"""Train one configuration.

  python scripts/train.py --config configs/base.yaml \
      --set model.name=resnet50 optim.lr=1e-4 data.splits_dir=splits
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from retina.engine import train  # noqa: E402
from retina.utils import load_config, parse_overrides  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/base.yaml")
    ap.add_argument("--set", nargs="*", default=[], help="dotted overrides, e.g. optim.lr=1e-4")
    a = ap.parse_args()
    cfg = load_config(a.config, parse_overrides(a.set))
    print(train(cfg))


if __name__ == "__main__":
    main()
