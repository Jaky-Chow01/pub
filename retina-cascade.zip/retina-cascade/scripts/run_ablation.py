#!/usr/bin/env python
"""Ablation grid (Phase B/C). Trains the teachers first, then every experiment for each seed.

  python scripts/run_ablation.py --set data.splits_dir=splits output_dir=runs/abl
  python scripts/run_ablation.py --only A6 A8 --seeds 42 49 202 --eval_test   # shortlist, 3 seeds, final test
IDs: A0 flat+BCE | A1 flat+best loss | A2 gate | A3 +grouped heads | A4 +cross-head | A5 +CBAM
     A6 A1+KD | A7 A1+label smoothing | A8 A5+KD | F flat+CBAM+KD
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from retina.engine import train  # noqa: E402
from retina.utils import deep_update, load_config, load_yaml, parse_overrides  # noqa: E402

FLAT = {"type": "flat", "cbam": False}
CASC_UNG = {"type": "cascade", "grouped": False, "cross_head": False, "cbam": False}
CASC_GRP = {"type": "cascade", "grouped": True, "cross_head": False, "cbam": False}
CASC_CHA = {"type": "cascade", "grouped": True, "cross_head": True, "cbam": False}


def experiments(best_loss):
    bce = {"type": "bce"}
    return {
        "A0": dict(head=FLAT, loss=bce),
        "A1": dict(head=FLAT, loss=best_loss),
        "A2": dict(head=CASC_UNG, loss=best_loss),
        "A3": dict(head=CASC_GRP, loss=best_loss),
        "A4": dict(head=CASC_CHA, loss=best_loss),
        "A5": dict(head={**CASC_CHA, "cbam": True}, loss=best_loss),
        "A6": dict(head=FLAT, loss=best_loss, kd="flat"),
        "A7": dict(head=FLAT, loss={**best_loss, "label_smoothing": 0.1}),
        "A8": dict(head={**CASC_CHA, "cbam": True}, loss=best_loss, kd="casc"),
        "F": dict(head={**FLAT, "cbam": True}, loss=best_loss, kd="flat"),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="configs/base.yaml")
    ap.add_argument("--ablation", default="configs/ablation.yaml")
    ap.add_argument("--set", nargs="*", default=[])
    ap.add_argument("--only", nargs="*", default=None)
    ap.add_argument("--seeds", nargs="*", type=int, default=None)
    ap.add_argument("--teacher_flat_run", default=None, help="reuse an existing flat teacher run dir")
    ap.add_argument("--teacher_casc_run", default=None, help="reuse an existing cascade teacher run dir")
    ap.add_argument("--eval_test", action="store_true", help="evaluate on test (final configs only)")
    ap.add_argument("--dry_run", action="store_true")
    a = ap.parse_args()

    base = load_config(a.base, parse_overrides(a.set))
    ab = load_yaml(a.ablation)
    out_dir = Path(base.get("output_dir", "runs"))
    seeds = a.seeds or ab.get("seeds", [42])
    exps = experiments(ab["best_loss"])
    chosen = [k for k in exps if not a.only or k in a.only]
    need_flat = any(exps[k].get("kd") == "flat" for k in chosen)
    need_casc = any(exps[k].get("kd") == "casc" for k in chosen)

    def make(name, seed, model_spec, head, loss, kd_cfg=None, test=False):
        over = {"seed": seed, "run_name": name,
                "model": {"name": model_spec["name"], "head": head},
                "data": {"res": model_spec["res"]}, "optim": {"lr": model_spec["lr"]},
                "loss": loss, "kd": kd_cfg or {"enabled": False},
                "eval": {"eval_test": test}}
        return deep_update(deep_update(base, over), model_spec.get("overrides"))

    for seed in seeds:
        teachers = {"flat": a.teacher_flat_run, "casc": a.teacher_casc_run}
        for kind, needed, head in (("flat", need_flat, FLAT), ("casc", need_casc, CASC_CHA)):
            if needed and not teachers[kind]:
                name = f"abl_T{kind}_s{seed}"
                teachers[kind] = str(out_dir / name)
                print(f"[teacher] {name}")
                if not a.dry_run and not (out_dir / name / "val_metrics.json").exists():
                    train(make(name, seed, ab["teacher"], head, ab["best_loss"], test=a.eval_test))
        for k in chosen:
            spec = exps[k]
            name = f"abl_{k}_s{seed}"
            kd_cfg = None
            if spec.get("kd"):
                kd_cfg = {"enabled": True, "teacher_run": teachers[spec["kd"]], **ab["kd"]}
            print(f"[exp] {name}")
            if a.dry_run or (out_dir / name / "val_metrics.json").exists():
                continue
            train(make(name, seed, ab["student"], spec["head"], spec["loss"], kd_cfg, a.eval_test))


if __name__ == "__main__":
    main()
