#!/usr/bin/env python
"""Grad-CAM++ overlays for randomly chosen correct and incorrect cases (CNN backbones).

  python scripts/explain.py --run runs/<run> --split test --n 6 --out explain --seed 0
Cases are sampled at random per disease label (true positives and false negatives), not hand-picked.
"""
import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from retina import LABELS  # noqa: E402
from retina.datasets import FundusDataset, IMAGENET_MEAN, IMAGENET_STD  # noqa: E402
from retina.engine import load_run, pick_device  # noqa: E402
from retina.models import to_scores  # noqa: E402
from retina.utils import load_json  # noqa: E402


def last_4d_module(model, x):
    last = {}
    hooks = []

    def mk(name):
        def h(m, i, o):
            if torch.is_tensor(o) and o.ndim == 4:
                last["name"], last["mod"] = name, m
        return h
    for n, m in model.named_modules():
        hooks.append(m.register_forward_hook(mk(n)))
    with torch.no_grad():
        model(x)
    for h in hooks:
        h.remove()
    return last["name"], last["mod"]


class GradCAMPP:
    def __init__(self, model, layer):
        self.model, self.act, self.grad = model, None, None
        layer.register_forward_hook(self._fwd)

    def _fwd(self, m, i, o):
        self.act = o
        o.register_hook(lambda g: setattr(self, "grad", g))

    def __call__(self, x, label_idx):
        self.model.zero_grad()
        out = self.model(x)
        s, _ = to_scores(out, self.model.head_type)
        s[:, label_idx].sum().backward()
        a, g = self.act.detach(), self.grad.detach()
        g2, g3 = g.pow(2), g.pow(3)
        denom = 2 * g2 + (a * g3).sum((2, 3), keepdim=True)
        alpha = g2 / torch.where(denom != 0, denom, torch.ones_like(denom))
        w = (alpha * F.relu(g)).sum((2, 3), keepdim=True)
        cam = F.relu((w * a).sum(1, keepdim=True))
        cam = F.interpolate(cam, size=x.shape[-2:], mode="bilinear", align_corners=False)
        cam = cam - cam.amin((2, 3), keepdim=True)
        cam = cam / cam.amax((2, 3), keepdim=True).clamp(min=1e-8)
        return cam[:, 0]


def overlay(rgb, cam):
    import matplotlib
    matplotlib.use("Agg")
    from matplotlib import cm
    heat = cm.jet(cam)[..., :3]
    return np.clip(0.55 * rgb + 0.45 * heat, 0, 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--split", default="test")
    ap.add_argument("--n", type=int, default=6, help="cases per label and outcome")
    ap.add_argument("--out", default="explain")
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    device = pick_device({"device": "auto"})
    model, cfg = load_run(a.run, device)
    if not model.is_cnn:
        raise SystemExit("Grad-CAM++ here supports CNN backbones only.")
    res = cfg["data"].get("res", 224)
    preds = pd.read_csv(Path(a.run) / f"{a.split}_preds.csv")
    th = load_json(Path(a.run) / "thresholds.json")["thresholds"]
    splits = pd.read_csv(Path(cfg["data"]["splits_dir"]) / f"{a.split}.csv")
    ds = FundusDataset(splits, res, train=False)
    key = {fn: i for i, fn in enumerate(splits["filename"])}
    rng = np.random.default_rng(a.seed)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    x0 = ds[0]["image"].unsqueeze(0).to(device)
    _, layer = last_4d_module(model, x0)
    cam_fn = GradCAMPP(model, layer)
    mean = torch.tensor(IMAGENET_MEAN).view(3, 1, 1)
    std = torch.tensor(IMAGENET_STD).view(3, 1, 1)
    n_saved = 0
    for j, l in enumerate(LABELS):
        if l == "N":
            continue
        pos = preds[preds[f"y_{l}"] == 1]
        hit = pos[pos[f"s_{l}"] >= th[l]]
        miss = pos[pos[f"s_{l}"] < th[l]]
        for tag, sub in (("TP", hit), ("FN", miss)):
            if len(sub) == 0:
                continue
            pick = sub.iloc[rng.choice(len(sub), min(a.n, len(sub)), replace=False)]
            for _, r in pick.iterrows():
                item = ds[key[r["filename"]]]
                x = item["image"].unsqueeze(0).to(device).requires_grad_(True)
                cam = cam_fn(x, j)[0].cpu().numpy()
                rgb = (item["image"] * std + mean).clamp(0, 1).permute(1, 2, 0).numpy()
                panel = np.concatenate([rgb, overlay(rgb, cam)], 1)
                Image.fromarray((panel * 255).astype(np.uint8)).save(
                    out / f"{l}_{tag}_{Path(str(r['filename'])).stem}_s{r[f's_{l}']:.2f}.png")
                n_saved += 1
    print(f"saved {n_saved} overlays to {out}")


if __name__ == "__main__":
    main()
