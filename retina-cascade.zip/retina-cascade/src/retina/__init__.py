"""retina-cascade: normal-gated, grouped-head, knowledge-distilled fundus classifier."""
LABELS = ["N", "D", "G", "C", "A", "H", "M", "O"]
DISEASES = LABELS[1:]
GROUPS = {
    "vascular": ["D", "H"],
    "structural": ["G", "A", "M"],
    "media_other": ["C", "O"],
}
