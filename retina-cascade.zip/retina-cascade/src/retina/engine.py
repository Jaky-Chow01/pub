import math
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

from . import LABELS, metrics as M
from .datasets import IMAGENET_MEAN, IMAGENET_STD, build_loaders
from .losses import kd_binary, make_criterion, smooth_targets, BCELoss
from .models import RetinaNet, to_scores
from .utils import (deep_update, load_json, load_yaml, measure_efficiency, save_json, save_yaml,
                    set_seed, slug)


def pick_device(cfg):
    want = cfg.get("device", "auto")
    if want == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(want)


def autocast_ctx(device, enabled):
    if device.type != "cuda" or not enabled:
        return torch.autocast(device_type="cpu", enabled=False)
    dt = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
    return torch.autocast(device_type="cuda", dtype=dt)


def run_name_from(cfg):
    if cfg.get("run_name"):
        return cfg["run_name"]
    m, h, l, k = cfg["model"], cfg["model"].get("head", {}), cfg["loss"], cfg.get("kd", {})
    ht = h.get("type", "flat")
    if ht == "cascade":
        ht += ("-grp" if h.get("grouped", True) else "-flat") + ("-cha" if h.get("cross_head", True) else "")
    ht += "-cbam" if h.get("cbam") else ""
    kd = "kd" if k.get("enabled") else "nokd"
    return slug(f"{m['name']}_{m.get('img_size', 224)}_{ht}_{l.get('type', 'bce')}_{kd}"
                f"_lr{cfg['optim']['lr']}_s{cfg['seed']}")


def build_model(cfg, device):
    mcfg = dict(cfg["model"])
    mcfg.setdefault("img_size", cfg["data"].get("res", 224))
    return RetinaNet(mcfg).to(device)


def load_run(run_dir, device):
    """Rebuild a trained model from a run directory (config.yaml + best.pt)."""
    run_dir = Path(run_dir)
    cfg = load_yaml(run_dir / "config.yaml")
    cfg["model"]["pretrained"] = False
    cfg["model"].pop("pretrained_path", None)
    model = build_model(cfg, device)
    model.load_state_dict(torch.load(run_dir / "best.pt", map_location=device))
    model.eval()
    return model, cfg


def class_counts_for(df, head_type):
    y = np.nan_to_num(df[[f"y_{l}" for l in LABELS]].to_numpy(dtype=np.float32))
    if head_type == "flat":
        return y.sum(0), len(y)
    abn = y[:, 0] == 0
    return y[abn][:, 1:].sum(0), int(abn.sum())


def resize_batch(x, res):
    if x.shape[-1] == res:
        return x
    return F.interpolate(x, size=(res, res), mode="bilinear", antialias=True, align_corners=False)


def task_loss(out, y, abn, head_type, crit, gate_crit, smoothing, gate_weight):
    if head_type == "flat":
        return crit(out["logits"], smooth_targets(y, smoothing))
    l_gate = gate_crit(out["gate"].unsqueeze(1), smooth_targets(abn, smoothing).unsqueeze(1))
    l_dis = crit(out["logits"], smooth_targets(y[:, 1:], smoothing), mask=abn > 0.5)
    return gate_weight * l_gate + l_dis


def kd_loss_fn(out, tout, abn, head_type, T):
    if head_type == "flat":
        return kd_binary(out["logits"], tout["logits"], T)
    l_gate = kd_binary(out["gate"].unsqueeze(1), tout["gate"].unsqueeze(1), T)
    l_dis = kd_binary(out["logits"], tout["logits"], T, mask=abn > 0.5)
    return l_gate + l_dis


@torch.no_grad()
def predict(model, loader, device, amp=True, res=None):
    model.eval()
    S, G, Y, I = [], [], [], []
    for b in loader:
        x = b["image"].to(device, non_blocking=True)
        if res:
            x = resize_batch(x, res)
        with autocast_ctx(device, amp):
            out = model(x)
        out = {k: (v.float() if v is not None else None) for k, v in out.items()}
        s, g = to_scores(out, model.head_type)
        S.append(s.cpu().numpy()); G.append(g.cpu().numpy())
        Y.append(b["y"].numpy()); I.append(b["idx"].numpy())
    return {"s": np.concatenate(S), "g": np.concatenate(G), "y": np.concatenate(Y),
            "idx": np.concatenate(I)}


def preds_frame(df, pred):
    d = df.iloc[pred["idx"]][["patient_id", "filename", "eye"]].reset_index(drop=True).copy()
    for j, l in enumerate(LABELS):
        d[f"y_{l}"] = pred["y"][:, j].astype(int)
    for j, l in enumerate(LABELS):
        d[f"s_{l}"] = pred["s"][:, j]
    d["gate"] = pred["g"]
    return d


def rule_for(head_type):
    return "direct" if head_type == "flat" else "cascade"


def evaluate_split(pred, df, thr, tau_g, head_type, ci_B=0):
    pids = df.iloc[pred["idx"]]["patient_id"].to_numpy()
    return M.full_report(pred["y"].astype(int), pred["s"], pred["g"], thr, tau_g,
                         rule_for(head_type), patient_ids=pids, ci_B=ci_B)


def make_optimizer(model, ocfg):
    lr, wd, ld = ocfg["lr"], ocfg.get("weight_decay", 0.05), ocfg.get("layer_decay", 1.0)
    groups = []
    if ld < 1.0:
        try:
            from timm.optim import param_groups_layer_decay
            for g in param_groups_layer_decay(model.backbone, weight_decay=wd, layer_decay=ld):
                g["base_lr"] = lr * g.get("lr_scale", 1.0)
                g["lr"] = g["base_lr"]
                groups.append(g)
        except Exception as e:  # fall back to a single backbone group
            print(f"[optim] layer decay unavailable ({e}); using one backbone group")
    if not groups:
        groups.append({"params": list(model.backbone.parameters()), "weight_decay": wd, "base_lr": lr, "lr": lr})
    head_params = list(model.head.parameters()) + (list(model.cbam.parameters()) if model.cbam is not None else [])
    hl = lr * ocfg.get("head_lr_mult", 10.0)
    groups.append({"params": head_params, "weight_decay": wd, "base_lr": hl, "lr": hl})
    for g in groups:
        g.pop("lr_scale", None)
    return torch.optim.AdamW(groups, betas=(0.9, 0.999))


def lr_factor(step, total, warmup):
    if step < warmup:
        return (step + 1) / max(warmup, 1)
    p = (step - warmup) / max(total - warmup, 1)
    return 0.5 * (1 + math.cos(math.pi * p))


def train(cfg):
    set_seed(cfg["seed"], cfg.get("deterministic", False))
    device = pick_device(cfg)
    name = run_name_from(cfg)
    run_dir = Path(cfg.get("output_dir", "runs")) / name
    run_dir.mkdir(parents=True, exist_ok=True)
    cfg = deep_update(cfg, {"run_name": name})
    save_yaml(cfg, run_dir / "config.yaml")

    res = cfg["data"].get("res", 224)
    cfg["model"]["img_size"] = res
    model = build_model(cfg, device)
    head_type = model.head_type

    kcfg = cfg.get("kd", {})
    teacher, loader_res = None, res
    if kcfg.get("enabled"):
        teacher, tcfg = load_run(kcfg["teacher_run"], device)
        if teacher.head_type != head_type:
            raise ValueError("teacher and student must use the same head type for KD "
                             f"({teacher.head_type} vs {head_type})")
        for p in teacher.parameters():
            p.requires_grad = False
        t_res = tcfg["data"].get("res", 224)
        loader_res = max(res, t_res)
    else:
        t_res = res

    loaders, dfs, train_ds = build_loaders(cfg, loader_res, need_test=False)
    cc, n = class_counts_for(dfs["train"], head_type)
    lcfg = cfg["loss"]
    crit = make_criterion(lcfg, cc, n)
    gate_crit = BCELoss()
    ocfg = cfg["optim"]
    opt = make_optimizer(model, ocfg)
    epochs = ocfg.get("epochs", 50)
    steps_per_epoch = len(loaders["train"])
    total_steps, warm = epochs * steps_per_epoch, ocfg.get("warmup_epochs", 5) * steps_per_epoch
    amp = ocfg.get("amp", True)
    use_scaler = device.type == "cuda" and amp and not torch.cuda.is_bf16_supported()
    scaler = torch.amp.GradScaler("cuda") if use_scaler else None

    alpha, T = kcfg.get("alpha", 0.7), kcfg.get("T", 4.0)
    best, best_ep, bad, step, hist = -1.0, -1, 0, 0, []
    for ep in range(epochs):
        model.train()
        t0, run_loss, nb = time.time(), 0.0, 0
        for b in loaders["train"]:
            for g in opt.param_groups:
                g["lr"] = g["base_lr"] * lr_factor(step, total_steps, warm)
            x = b["image"].to(device, non_blocking=True)
            y, abn = b["y"].to(device), b["abn"].to(device)
            xs = resize_batch(x, res)
            with autocast_ctx(device, amp):
                out = model(xs)
                out = {k: (v.float() if v is not None else None) for k, v in out.items()}
                loss = task_loss(out, y, abn, head_type, crit, gate_crit, lcfg.get("label_smoothing", 0.0),
                                 lcfg.get("gate_weight", 1.0))
                if teacher is not None:
                    with torch.no_grad():
                        tout = teacher(resize_batch(x, t_res))
                        tout = {k: (v.float() if v is not None else None) for k, v in tout.items()}
                    loss = alpha * loss + (1 - alpha) * kd_loss_fn(out, tout, abn, head_type, T)
            opt.zero_grad(set_to_none=True)
            if scaler:
                scaler.scale(loss).backward()
                scaler.unscale_(opt)
                torch.nn.utils.clip_grad_norm_(model.parameters(), ocfg.get("grad_clip", 1.0))
                scaler.step(opt); scaler.update()
            else:
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), ocfg.get("grad_clip", 1.0))
                opt.step()
            run_loss += float(loss.detach()); nb += 1; step += 1
        pred = predict(model, loaders["val"], device, amp, res=res)
        v_auc = M.macro_auc(pred["y"].astype(int), pred["s"])
        hist.append({"epoch": ep, "train_loss": run_loss / max(nb, 1), "val_macro_auc": v_auc,
                     "sec": round(time.time() - t0, 1)})
        print(f"[{name}] ep {ep:03d} loss {hist[-1]['train_loss']:.4f} val_auc {v_auc:.4f}", flush=True)
        if v_auc > best:
            best, best_ep, bad = v_auc, ep, 0
            torch.save(model.state_dict(), run_dir / "best.pt")
        else:
            bad += 1
            if bad >= ocfg.get("patience", 10):
                break
    pd.DataFrame(hist).to_csv(run_dir / "history.csv", index=False)

    # ---- final evaluation with the best checkpoint ----
    model.load_state_dict(torch.load(run_dir / "best.pt", map_location=device))
    ecfg = cfg.get("eval", {})
    vp = predict(model, loaders["val"], device, amp, res=res)
    yv = vp["y"].astype(int)
    thr = M.tune_thresholds(yv, vp["s"], ecfg.get("threshold_metric", "f1"))
    tau_g = M.tune_gate_threshold(1 - yv[:, 0], vp["g"], ecfg.get("gate_sensitivity", 0.95))
    save_json({"thresholds": {l: float(thr[j]) for j, l in enumerate(LABELS)}, "gate_tau": tau_g,
               "rule": rule_for(head_type)}, run_dir / "thresholds.json")
    preds_frame(dfs["val"], vp).to_csv(run_dir / "val_preds.csv", index=False)
    val_rep = evaluate_split(vp, dfs["val"], thr, tau_g, head_type)
    val_rep.update({"best_epoch": best_ep, "epochs_run": len(hist)})
    save_json(val_rep, run_dir / "val_metrics.json")
    eff = measure_efficiency(model, res, device)
    save_json(eff, run_dir / "efficiency.json")

    if ecfg.get("eval_test", False):
        evaluate_test(run_dir, cfg, model, device, thr, tau_g)
    print(f"[{name}] best val macro AUC {best:.4f} at epoch {best_ep}")
    return {"run_dir": str(run_dir), "name": name, "val_macro_auc": best, **eff}


def evaluate_test(run_dir, cfg, model, device, thr, tau_g, ci_B=1000):
    """Evaluate on the test split with thresholds frozen on validation. Call once per final config."""
    res = cfg["data"].get("res", 224)
    loaders, dfs, _ = build_loaders(cfg, res, need_test=True)
    tp = predict(model, loaders["test"], device, cfg["optim"].get("amp", True), res=res)
    preds_frame(dfs["test"], tp).to_csv(Path(run_dir) / "test_preds.csv", index=False)
    rep = evaluate_split(tp, dfs["test"], thr, tau_g, model.head_type, ci_B=ci_B)
    save_json(rep, Path(run_dir) / "test_metrics.json")
    return rep
