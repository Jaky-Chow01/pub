import torch
import torch.nn as nn
import timm

from . import DISEASES, GROUPS, LABELS


class CBAM(nn.Module):
    """Convolutional block attention module (channel then spatial)."""

    def __init__(self, ch, reduction=16, kernel=7):
        super().__init__()
        hid = max(ch // reduction, 4)
        self.mlp = nn.Sequential(nn.Linear(ch, hid), nn.ReLU(inplace=True), nn.Linear(hid, ch))
        self.spatial = nn.Conv2d(2, 1, kernel, padding=kernel // 2, bias=False)

    def forward(self, x):
        b, c, _, _ = x.shape
        ca = torch.sigmoid(self.mlp(x.mean((2, 3))) + self.mlp(x.amax((2, 3)))).view(b, c, 1, 1)
        x = x * ca
        sa = torch.sigmoid(self.spatial(torch.cat([x.mean(1, keepdim=True), x.amax(1, keepdim=True)], 1)))
        return x * sa


def mlp(i, h, o=None, p=0.3):
    layers = [nn.Linear(i, h), nn.ReLU(inplace=True), nn.Dropout(p)]
    if o is not None:
        layers.append(nn.Linear(h, o))
    return nn.Sequential(*layers)


class CrossHeadAttention(nn.Module):
    """Self-attention over the group tokens, then residual + layer norm."""

    def __init__(self, dim, heads=4, dropout=0.1):
        super().__init__()
        self.attn = nn.MultiheadAttention(dim, heads, dropout=dropout, batch_first=True)
        self.norm = nn.LayerNorm(dim)

    def forward(self, tokens):
        out, _ = self.attn(tokens, tokens, tokens, need_weights=False)
        return self.norm(tokens + out)


class FlatHead(nn.Module):
    def __init__(self, in_dim, n_out, hidden=256, dropout=0.3):
        super().__init__()
        self.net = mlp(in_dim, hidden, n_out, dropout)

    def forward(self, f):
        return None, self.net(f)


class CascadeHead(nn.Module):
    """Gate (normal vs abnormal) + disease logits for D,G,C,A,H,M,O."""

    def __init__(self, in_dim, hidden=256, dropout=0.3, grouped=True, cross_head=True, heads=4):
        super().__init__()
        self.gate = mlp(in_dim, hidden, 1, dropout)
        self.grouped = grouped
        if grouped:
            self.enc = nn.ModuleDict({g: mlp(in_dim, hidden, None, dropout) for g in GROUPS})
            self.cls = nn.ModuleDict({g: nn.Linear(hidden, len(v)) for g, v in GROUPS.items()})
            self.cross = CrossHeadAttention(hidden, heads) if cross_head else None
            order = [l for g in GROUPS for l in GROUPS[g]]
            self.register_buffer("perm", torch.tensor([order.index(d) for d in DISEASES]), persistent=False)
        else:
            self.flat = mlp(in_dim, hidden, len(DISEASES), dropout)

    def forward(self, f):
        gate = self.gate(f).squeeze(-1)
        if not self.grouped:
            return gate, self.flat(f)
        toks = torch.stack([self.enc[g](f) for g in GROUPS], 1)  # (B, G, H)
        if self.cross is not None:
            toks = self.cross(toks)
        logits = torch.cat([self.cls[g](toks[:, i]) for i, g in enumerate(GROUPS)], 1)
        return gate, logits[:, self.perm]


class RetinaNet(nn.Module):
    def __init__(self, mcfg, device_hint="cpu"):
        super().__init__()
        name = mcfg["name"]
        res = mcfg.get("img_size", 224)
        kw = {}
        if any(k in name for k in ("vit", "deit", "swin")):
            kw["img_size"] = res
        if mcfg.get("global_pool"):
            kw["global_pool"] = mcfg["global_pool"]
        if mcfg.get("drop_path", 0.0) > 0:
            kw["drop_path_rate"] = mcfg["drop_path"]
        use_hub = bool(mcfg.get("pretrained", True)) and not mcfg.get("pretrained_path")
        self.backbone = timm.create_model(name, pretrained=use_hub, num_classes=0, **kw)
        if mcfg.get("pretrained_path"):
            load_backbone_checkpoint(self.backbone, mcfg["pretrained_path"])
        nf = self.backbone.num_features

        # detect CNN feature maps (needed for CBAM)
        was = self.backbone.training
        self.backbone.eval()
        with torch.no_grad():
            f = self.backbone.forward_features(torch.zeros(1, 3, res, res))
            feat_dim = self.backbone.forward_head(f, pre_logits=True).shape[-1]
        self.backbone.train(was)
        self.is_cnn = f.ndim == 4 and f.shape[1] == nf
        h = mcfg.get("head", {})
        self.cbam = None
        if h.get("cbam", False):
            if not self.is_cnn:
                raise ValueError(f"CBAM needs a CNN feature map; {name} is not a CNN")
            self.cbam = CBAM(f.shape[1])
        self.head_type = h.get("type", "flat")
        hid, dr = h.get("hidden", 256), h.get("dropout", 0.3)
        if self.head_type == "flat":
            self.head = FlatHead(feat_dim, len(LABELS), hid, dr)
        elif self.head_type == "cascade":
            self.head = CascadeHead(feat_dim, hid, dr, h.get("grouped", True), h.get("cross_head", True),
                                    h.get("attn_heads", 4))
        else:
            raise ValueError(f"unknown head type {self.head_type}")

    def features(self, x):
        f = self.backbone.forward_features(x)
        if self.cbam is not None:
            f = self.cbam(f)
        return self.backbone.forward_head(f, pre_logits=True)

    def forward(self, x):
        gate, logits = self.head(self.features(x))
        return {"gate": gate, "logits": logits}


def load_backbone_checkpoint(backbone, path):
    """Load a local checkpoint (e.g. RETFound weights) into a timm backbone."""
    sd = torch.load(path, map_location="cpu")
    sd = sd.get("model", sd.get("state_dict", sd))
    sd = {k.replace("module.", "", 1): v for k, v in sd.items() if not k.startswith("head.")}
    if "pos_embed" in sd and hasattr(backbone, "patch_embed"):
        from timm.layers import resample_abs_pos_embed
        if sd["pos_embed"].shape != backbone.pos_embed.shape:
            sd["pos_embed"] = resample_abs_pos_embed(
                sd["pos_embed"], new_size=backbone.patch_embed.grid_size,
                num_prefix_tokens=getattr(backbone, "num_prefix_tokens", 1))
    missing, unexpected = backbone.load_state_dict(sd, strict=False)
    print(f"[checkpoint] loaded {path}: {len(missing)} missing, {len(unexpected)} unexpected keys")
    return missing, unexpected


def to_scores(out, head_type):
    """Convert model output to an (B, 8) probability matrix in LABELS order, plus gate prob.

    flat:    sigmoid over the 8 outputs; gate = 1 - P(N)
    cascade: P(N) = 1 - P(abn); P(d) = P(abn) * P(d | abn)
    """
    if head_type == "flat":
        s = torch.sigmoid(out["logits"])
        return s, 1.0 - s[:, 0]
    g = torch.sigmoid(out["gate"])
    d = torch.sigmoid(out["logits"])
    s = torch.cat([(1.0 - g).unsqueeze(1), g.unsqueeze(1) * d], 1)
    return s, g
