import copy
import json
import random
import re
import time

import numpy as np
import torch
import yaml


def set_seed(seed, deterministic=False):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    else:
        torch.backends.cudnn.benchmark = True


def deep_update(base, upd):
    out = copy.deepcopy(base)
    for k, v in (upd or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_update(out[k], v)
        else:
            out[k] = copy.deepcopy(v)
    return out


def load_yaml(path):
    with open(path) as f:
        return yaml.safe_load(f)


def save_yaml(obj, path):
    with open(path, "w") as f:
        yaml.safe_dump(obj, f, sort_keys=False)


def load_config(path, overrides=None):
    return deep_update(load_yaml(path), overrides or {})


def parse_overrides(items):
    """['optim.lr=1e-4', 'model.name=resnet50'] -> nested dict (values parsed as YAML)."""
    out = {}
    for it in items or []:
        key, val = it.split("=", 1)
        val = yaml.safe_load(val)
        d = out
        parts = key.split(".")
        for p in parts[:-1]:
            d = d.setdefault(p, {})
        d[parts[-1]] = val
    return out


def _default(o):
    return o.item() if hasattr(o, "item") else str(o)


def save_json(obj, path):
    with open(path, "w") as f:
        json.dump(obj, f, indent=2, default=_default)


def load_json(path):
    with open(path) as f:
        return json.load(f)


def slug(s):
    return re.sub(r"[^A-Za-z0-9_.-]+", "-", str(s)).strip("-")


def count_params(model):
    return int(sum(p.numel() for p in model.parameters()))


@torch.no_grad()
def measure_efficiency(model, res, device, n_warm=3, n_iter=10):
    """Params, counted FLOPs (2 x MACs) at batch 1, and latency at batch 1 on `device`."""
    from torch.utils.flop_counter import FlopCounterMode

    model.eval()
    x = torch.randn(1, 3, res, res)
    cpu_model = copy.deepcopy(model).cpu().eval()
    with FlopCounterMode(display=False) as fc:
        cpu_model(x)
    flops = fc.get_total_flops()
    del cpu_model
    xd = x.to(device)
    for _ in range(n_warm):
        model(xd)
    if device.type == "cuda":
        torch.cuda.synchronize()
    t0 = time.perf_counter()
    for _ in range(n_iter):
        model(xd)
    if device.type == "cuda":
        torch.cuda.synchronize()
    lat = (time.perf_counter() - t0) / n_iter * 1000
    n = count_params(model)
    return {
        "params": n,
        "params_m": round(n / 1e6, 3),
        "gflops": round(flops / 1e9, 3),
        "gmacs": round(flops / 2e9, 3),
        "latency_ms_bs1": round(lat, 2),
        "device": str(device),
    }
