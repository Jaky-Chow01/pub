import numpy as np
from scipy.stats import norm
from sklearn.metrics import average_precision_score, f1_score, matthews_corrcoef, roc_auc_score, roc_curve

from . import LABELS


def _valid(y_col):
    return 0 < y_col.sum() < len(y_col)


def per_label_auc(y, s, labels=LABELS):
    return {l: (float(roc_auc_score(y[:, j], s[:, j])) if _valid(y[:, j]) else float("nan"))
            for j, l in enumerate(labels)}


def per_label_ap(y, s, labels=LABELS):
    return {l: (float(average_precision_score(y[:, j], s[:, j])) if y[:, j].sum() > 0 else float("nan"))
            for j, l in enumerate(labels)}


def macro(d, exclude=()):
    v = [x for k, x in d.items() if k not in exclude and not np.isnan(x)]
    return float(np.mean(v)) if v else float("nan")


def macro_auc(y, s, exclude=()):
    return macro(per_label_auc(y, s), exclude)


def ece_binary(y, p, bins=15):
    edges = np.linspace(0, 1, bins + 1)
    idx = np.clip(np.digitize(p, edges[1:-1]), 0, bins - 1)
    e = 0.0
    for b in range(bins):
        m = idx == b
        if m.any():
            e += m.mean() * abs(y[m].mean() - p[m].mean())
    return float(e)


def sens_at_spec(y, score, spec=0.95):
    fpr, tpr, thr = roc_curve(y, score)
    ok = fpr <= 1 - spec
    return float(tpr[ok].max()) if ok.any() else 0.0


def tune_thresholds(y, s, metric="f1", n_grid=200):
    """Per-label threshold maximizing F1 (or Youden's J) on validation data."""
    thr = np.full(y.shape[1], 0.5)
    for j in range(y.shape[1]):
        if not _valid(y[:, j]):
            continue
        cand = np.unique(np.quantile(s[:, j], np.linspace(0.01, 0.99, n_grid)))
        best, bt = -1, 0.5
        for t in cand:
            pred = s[:, j] >= t
            if metric == "youden":
                tp = (pred & (y[:, j] == 1)).sum()
                tn = (~pred & (y[:, j] == 0)).sum()
                v = tp / max((y[:, j] == 1).sum(), 1) + tn / max((y[:, j] == 0).sum(), 1) - 1
            else:
                v = f1_score(y[:, j], pred, zero_division=0)
            if v > best:
                best, bt = v, t
        thr[j] = bt
    return thr


def tune_gate_threshold(abn, g, target_sens=0.95):
    """Largest threshold whose sensitivity for abnormal images is at least target_sens."""
    fpr, tpr, thr = roc_curve(abn, g)
    ok = np.where(tpr >= target_sens)[0]
    return float(thr[ok[0]]) if len(ok) else float(thr[-1])


def decide(scores, gate, thr, tau_g, rule):
    if rule == "direct":
        return (scores >= thr[None]).astype(int)
    abn = gate >= tau_g
    pred = np.zeros(scores.shape, dtype=int)
    for j, l in enumerate(LABELS):
        if l != "N":
            pred[:, j] = ((scores[:, j] >= thr[j]) & abn).astype(int)
    none = abn & (pred[:, 1:].sum(1) == 0)
    pred[none, LABELS.index("O")] = 1
    pred[:, 0] = (~abn).astype(int)
    return pred


def cls_metrics(y, pred):
    f1 = {l: float(f1_score(y[:, j], pred[:, j], zero_division=0)) for j, l in enumerate(LABELS)}
    mcc = {}
    for j, l in enumerate(LABELS):
        mcc[l] = float(matthews_corrcoef(y[:, j], pred[:, j])) if _valid(y[:, j]) else float("nan")
    return f1, mcc


def gate_metrics(abn, g, tau_g):
    out = {}
    if _valid(abn):
        out["gate_auc"] = float(roc_auc_score(abn, g))
        out["gate_sens_at_95spec"] = sens_at_spec(abn, g, 0.95)
    pred = g >= tau_g
    pos, neg = abn == 1, abn == 0
    out["gate_tau"] = float(tau_g)
    out["gate_sensitivity"] = float(pred[pos].mean()) if pos.any() else float("nan")
    out["gate_specificity"] = float((~pred[neg]).mean()) if neg.any() else float("nan")
    return out


def patient_bootstrap_indices(patient_ids, B, seed=0):
    rng = np.random.default_rng(seed)
    pids = np.asarray(patient_ids)
    uniq, inv = np.unique(pids, return_inverse=True)
    groups = [np.where(inv == i)[0] for i in range(len(uniq))]
    for _ in range(B):
        pick = rng.integers(0, len(uniq), len(uniq))
        yield np.concatenate([groups[i] for i in pick])


def bootstrap_ci(fn, patient_ids, B=1000, seed=0):
    vals = []
    for idx in patient_bootstrap_indices(patient_ids, B, seed):
        v = fn(idx)
        if not np.isnan(v):
            vals.append(v)
    if not vals:
        return [float("nan")] * 2
    return [float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))]


def paired_bootstrap(fn_a, fn_b, patient_ids, B=2000, seed=0):
    """Difference (a - b) of a metric on identical resamples; returns mean, 95% CI, P(diff <= 0)."""
    d = []
    for idx in patient_bootstrap_indices(patient_ids, B, seed):
        va, vb = fn_a(idx), fn_b(idx)
        if not (np.isnan(va) or np.isnan(vb)):
            d.append(va - vb)
    d = np.asarray(d)
    if len(d) == 0:
        return {"mean": float("nan"), "ci": [float("nan")] * 2, "p_le_0": float("nan")}
    return {"mean": float(d.mean()), "ci": [float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5))],
            "p_le_0": float((d <= 0).mean())}


# ---- DeLong test (Sun and Xu, 2014) ----
def _midrank(x):
    J = np.argsort(x)
    Z = x[J]
    N = len(x)
    T = np.zeros(N)
    i = 0
    while i < N:
        j = i
        while j < N and Z[j] == Z[i]:
            j += 1
        T[i:j] = 0.5 * (i + j - 1)
        i = j
    out = np.empty(N)
    out[J] = T + 1
    return out


def delong_test(y, p1, p2):
    """Two-sided DeLong test for two correlated AUCs on the same images. Returns (auc1, auc2, p)."""
    y = np.asarray(y).astype(int)
    order = np.argsort(-y, kind="stable")
    m = int(y.sum())
    n = len(y) - m
    if m < 2 or n < 2:
        return float("nan"), float("nan"), float("nan")
    preds = np.vstack([np.asarray(p1)[order], np.asarray(p2)[order]])
    k = 2
    pos, neg = preds[:, :m], preds[:, m:]
    tx = np.array([_midrank(pos[r]) for r in range(k)])
    ty = np.array([_midrank(neg[r]) for r in range(k)])
    tz = np.array([_midrank(preds[r]) for r in range(k)])
    aucs = tz[:, :m].sum(1) / m / n - (m + 1.0) / 2.0 / n
    v01 = (tz[:, :m] - tx) / n
    v10 = 1.0 - (tz[:, m:] - ty) / m
    cov = np.cov(v01) / m + np.cov(v10) / n
    var = cov[0, 0] + cov[1, 1] - 2 * cov[0, 1]
    if var <= 0:
        return float(aucs[0]), float(aucs[1]), float("nan")
    z = (aucs[0] - aucs[1]) / np.sqrt(var)
    return float(aucs[0]), float(aucs[1]), float(2 * (1 - norm.cdf(abs(z))))


def full_report(y, s, gate, thr, tau_g, rule, patient_ids=None, ci_B=0, labels_mask=None):
    """Complete metric dictionary for one set of predictions.

    y, s: (N, 8). gate: (N,) abnormal score. thr: (8,). labels_mask: optional list of label
    names to evaluate (used for external data where only some labels map)."""
    labs = [l for l in LABELS if labels_mask is None or l in labels_mask]
    auc = per_label_auc(y, s)
    ap = per_label_ap(y, s)
    auc = {l: auc[l] for l in labs}
    ap = {l: ap[l] for l in labs}
    pred = decide(s, gate, thr, tau_g, rule)
    f1, mcc = cls_metrics(y, pred)
    f1 = {l: f1[l] for l in labs}
    mcc = {l: mcc[l] for l in labs}
    ece = {l: ece_binary(y[:, LABELS.index(l)], s[:, LABELS.index(l)]) for l in labs}
    rep = {
        "n_images": int(len(y)),
        "auc": auc, "ap": ap, "f1": f1, "mcc": mcc, "ece": ece,
        "macro_auc": macro(auc), "macro_auc_no_O": macro(auc, ("O",)),
        "macro_ap": macro(ap), "macro_f1": macro(f1), "macro_mcc": macro(mcc),
        "macro_ece": macro(ece),
        "thresholds": {l: float(thr[j]) for j, l in enumerate(LABELS)},
    }
    rep.update(gate_metrics(1 - y[:, 0], gate, tau_g))
    if patient_ids is not None and ci_B:
        cols = [LABELS.index(l) for l in labs]

        def f_auc(idx):
            vals = [roc_auc_score(y[idx, j], s[idx, j]) for j in cols if _valid(y[idx, j])]
            return float(np.mean(vals)) if vals else float("nan")

        rep["macro_auc_ci95"] = bootstrap_ci(f_auc, patient_ids, ci_B)
        a = 1 - y[:, 0]
        rep["gate_auc_ci95"] = bootstrap_ci(
            lambda idx: float(roc_auc_score(a[idx], gate[idx])) if _valid(a[idx]) else float("nan"),
            patient_ids, ci_B)
    return rep
