import numpy as np
import pandas as pd
import torch
from PIL import Image
from torch.utils.data import DataLoader, Dataset, WeightedRandomSampler
from torchvision import transforms as T

from . import LABELS

IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)


def crop_black_border(img, thr=10, margin=2):
    """Crop the black background around the fundus disc and pad to a square."""
    arr = np.asarray(img.convert("L"))
    mask = arr > thr
    if mask.any():
        ys, xs = np.where(mask)
        y0, y1 = max(ys.min() - margin, 0), min(ys.max() + margin + 1, arr.shape[0])
        x0, x1 = max(xs.min() - margin, 0), min(xs.max() + margin + 1, arr.shape[1])
        img = img.crop((x0, y0, x1, y1))
    w, h = img.size
    s = max(w, h)
    canvas = Image.new("RGB", (s, s), (0, 0, 0))
    canvas.paste(img.convert("RGB"), ((s - w) // 2, (s - h) // 2))
    return canvas


def build_transforms(res, train, mean=IMAGENET_MEAN, std=IMAGENET_STD, aug=None):
    aug = aug or {}
    norm = T.Normalize(mean, std)
    if not train:
        return T.Compose([T.Resize((res, res)), T.ToTensor(), norm])
    ops = [T.RandomResizedCrop(res, scale=tuple(aug.get("crop_scale", (0.8, 1.0))), ratio=(0.95, 1.05))]
    if aug.get("hflip", 0.5) > 0:
        ops.append(T.RandomHorizontalFlip(aug.get("hflip", 0.5)))
    if aug.get("vflip", 0.0) > 0:
        ops.append(T.RandomVerticalFlip(aug["vflip"]))
    if aug.get("rotate", 20) > 0:
        ops.append(T.RandomRotation(aug.get("rotate", 20)))
    cj = aug.get("color_jitter", (0.2, 0.2, 0.1))
    if cj and any(v > 0 for v in cj):
        ops.append(T.ColorJitter(brightness=cj[0], contrast=cj[1], saturation=cj[2], hue=0.0))
    ops += [T.ToTensor(), norm]
    return T.Compose(ops)


class FundusDataset(Dataset):
    """Reads a split CSV (columns: path or cache_path, patient_id, filename, eye, y_N..y_O)."""

    def __init__(self, df, res, train, mean=IMAGENET_MEAN, std=IMAGENET_STD, aug=None,
                 crop_on_load=None):
        self.df = df.reset_index(drop=True)
        self.path_col = "cache_path" if "cache_path" in self.df.columns else "path"
        # cached images are already cropped and squared
        self.crop_on_load = (self.path_col == "path") if crop_on_load is None else crop_on_load
        self.tf = build_transforms(res, train, mean, std, aug)
        ycols = [f"y_{l}" for l in LABELS]
        self.y = np.nan_to_num(self.df[ycols].to_numpy(dtype=np.float32), nan=0.0)
        if "abnormal" in self.df.columns:
            self.abn = np.nan_to_num(self.df["abnormal"].to_numpy(dtype=np.float32), nan=0.0)
        else:
            self.abn = 1.0 - self.y[:, 0]

    def __len__(self):
        return len(self.df)

    def __getitem__(self, i):
        img = Image.open(self.df.at[i, self.path_col]).convert("RGB")
        if self.crop_on_load:
            img = crop_black_border(img)
        return {
            "image": self.tf(img),
            "y": torch.from_numpy(self.y[i]),
            "abn": torch.tensor(self.abn[i]),
            "idx": i,
        }


def rarest_inverse_weights(y):
    """Weight = 1 / frequency of the rarest positive label of each image (thesis scheme)."""
    freq = y.mean(0).clip(min=1e-6)
    w = np.ones(len(y), dtype=np.float64)
    for i in range(len(y)):
        pos = np.where(y[i] > 0)[0]
        if len(pos):
            w[i] = 1.0 / freq[pos].min()
    return w


def build_loaders(cfg, res, mean=IMAGENET_MEAN, std=IMAGENET_STD, need_test=False):
    d = cfg["data"]
    sd = d["splits_dir"]
    dfs = {s: pd.read_csv(f"{sd}/{s}.csv") for s in ("train", "val")}
    if need_test:
        dfs["test"] = pd.read_csv(f"{sd}/test.csv")
    if d.get("limit"):  # debugging
        dfs = {k: v.sample(min(len(v), d["limit"]), random_state=0) for k, v in dfs.items()}
    aug = d.get("aug")
    train_ds = FundusDataset(dfs["train"], res, True, mean, std, aug)
    sampler = None
    if d.get("sampler", "none") == "rarest_inv":
        w = rarest_inverse_weights(train_ds.y)
        sampler = WeightedRandomSampler(torch.as_tensor(w), num_samples=len(w), replacement=True)
    kw = dict(num_workers=d.get("num_workers", 4), pin_memory=torch.cuda.is_available(),
              persistent_workers=d.get("num_workers", 4) > 0)
    bs = d.get("batch_size", 32)
    loaders = {
        "train": DataLoader(train_ds, batch_size=bs, shuffle=sampler is None, sampler=sampler,
                            drop_last=True, **kw),
    }
    for s in ("val", "test"):
        if s in dfs:
            loaders[s] = DataLoader(FundusDataset(dfs[s], res, False, mean, std), batch_size=bs * 2,
                                    shuffle=False, **kw)
    return loaders, dfs, train_ds
