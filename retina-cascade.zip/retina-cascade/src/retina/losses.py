import numpy as np
import torch
import torch.nn.functional as F


def _reduce(elem, mask):
    """elem: (B,K) per-element loss; mask: (B,) rows to count or None."""
    if mask is None:
        return elem.mean()
    m = mask.float().unsqueeze(1)
    return (elem * m).sum() / (m.sum().clamp(min=1.0) * elem.shape[1])


class BCELoss:
    def __init__(self, pos_weight=None):
        self.pw = None if pos_weight is None else torch.as_tensor(pos_weight, dtype=torch.float32)

    def __call__(self, z, y, mask=None):
        pw = None if self.pw is None else self.pw.to(z.device)
        return _reduce(F.binary_cross_entropy_with_logits(z, y, pos_weight=pw, reduction="none"), mask)


class ASLoss:
    """Asymmetric loss (Ridnik et al., ICCV 2021). gamma_pos=1, gamma_neg=0 reproduces the thesis setting."""

    def __init__(self, gamma_pos=0.0, gamma_neg=4.0, clip=0.05, eps=1e-8):
        self.gp, self.gn, self.clip, self.eps = gamma_pos, gamma_neg, clip, eps

    def __call__(self, z, y, mask=None):
        p = torch.sigmoid(z)
        p_m = (p - self.clip).clamp(min=0) if self.clip else p
        lp = y * (1 - p).pow(self.gp) * torch.log(p.clamp(min=self.eps))
        ln = (1 - y) * p_m.pow(self.gn) * torch.log((1 - p_m).clamp(min=self.eps))
        return _reduce(-(lp + ln), mask)


class DBLoss:
    """Simplified distribution-balanced loss (Wu et al., ECCV 2020):
    re-balanced weights + negative-tolerant regularization on top of BCE."""

    def __init__(self, class_counts, n_samples, alpha=0.1, beta=10.0, mu=0.3, lam=2.0, kappa=0.05):
        counts = torch.as_tensor(np.maximum(class_counts, 1), dtype=torch.float32)
        self.K = len(counts)
        self.inv_n = 1.0 / counts
        prior = (counts / float(n_samples)).clamp(1e-6, 1 - 1e-6)
        self.bias = kappa * torch.log(prior / (1 - prior))
        self.alpha, self.beta, self.mu, self.lam = alpha, beta, mu, lam

    def __call__(self, z, y, mask=None):
        dev = z.device
        inv_n, bias = self.inv_n.to(dev), self.bias.to(dev)
        p_c = inv_n / self.K
        p_i = (y * inv_n).sum(1, keepdim=True) / self.K
        p_i = torch.where(p_i > 0, p_i, p_c.mean().expand_as(p_i))
        w = self.alpha + torch.sigmoid(self.beta * (p_c.unsqueeze(0) / p_i - self.mu))
        z2 = z * (y + (1 - y) * self.lam) + bias
        elem = F.binary_cross_entropy_with_logits(z2, y, reduction="none") * w
        elem = torch.where(y > 0, elem, elem / self.lam)
        return _reduce(elem, mask)


def make_criterion(lcfg, class_counts, n_samples):
    t = lcfg.get("type", "bce")
    if t == "bce":
        pw = None
        if lcfg.get("pos_weight") == "auto":
            pw = (n_samples - class_counts) / np.maximum(class_counts, 1)
        return BCELoss(pw)
    if t == "asl":
        return ASLoss(lcfg.get("gamma_pos", 0.0), lcfg.get("gamma_neg", 4.0), lcfg.get("clip", 0.05))
    if t == "db":
        return DBLoss(class_counts, n_samples)
    raise ValueError(f"unknown loss {t}")


def smooth_targets(y, eps):
    return y * (1 - eps) + 0.5 * eps if eps > 0 else y


def kd_binary(z_s, z_t, T, mask=None):
    """Per-label binary KL(teacher || student) at temperature T, scaled by T^2."""
    pt = torch.sigmoid(z_t / T)
    ce = F.binary_cross_entropy_with_logits(z_s / T, pt, reduction="none")
    ent = -(pt * torch.log(pt.clamp(min=1e-8)) + (1 - pt) * torch.log((1 - pt).clamp(min=1e-8)))
    return _reduce(ce - ent, mask) * (T * T)
