#!/usr/bin/env python
"""Build patient-level train/val/test splits from the audit output.

Both eyes of a patient always land in the same split. Stratification uses
iterative multi-label stratification on the patient's 8-label vector.

Usage:
  python 02_make_splits.py --eye_table audit/eye_table.csv --out splits \
      --label_mode eye --seed 42 --drop_missing --drop_cross_patient_dups
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from odir_labels import LABELS

try:
    from iterstrat.ml_stratifiers import MultilabelStratifiedShuffleSplit
except ImportError as e:  # pragma: no cover
    raise SystemExit("Install iterative-stratification: pip install iterative-stratification") from e


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--eye_table", required=True)
    ap.add_argument("--duplicates", default=None,
                    help="duplicates.csv from the audit (default: next to eye_table)")
    ap.add_argument("--out", default="splits")
    ap.add_argument("--label_mode", choices=["eye", "patient"], default="eye",
                    help="eye: labels from per-eye keywords; patient: patient-level labels for both eyes")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--val", type=float, default=0.15)
    ap.add_argument("--test", type=float, default=0.15)
    ap.add_argument("--drop_missing", action="store_true")
    ap.add_argument("--drop_quality", action="store_true",
                    help="drop eyes whose keywords contain a quality token (review the list first)")
    ap.add_argument("--drop_cross_patient_dups", action="store_true",
                    help="drop the second image of every cross-patient duplicate pair")
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(args.eye_table)
    report = {"start_rows": int(len(df))}

    if args.drop_missing:
        df = df[df["file_exists"]]
        report["after_drop_missing"] = int(len(df))

    if args.drop_quality:
        df = df[~df["has_quality_token"]]
        report["after_drop_quality"] = int(len(df))

    if args.drop_cross_patient_dups:
        dpath = Path(args.duplicates) if args.duplicates else Path(args.eye_table).parent / "duplicates.csv"
        if dpath.exists() and dpath.stat().st_size > 2:
            d = pd.read_csv(dpath)
            d = d[d["cross_patient"]]
            drop_files = set(d["file_b"])
            df = df[~df["filename"].isin(drop_files)]
            report["after_drop_cross_patient_dups"] = int(len(df))

    prefix = "eye_" if args.label_mode == "eye" else "patient_"
    for l in LABELS:
        df[f"y_{l}"] = df[f"{prefix}{l}"].astype(int)

    # eyes with no label at all cannot be used
    has_label = df[[f"y_{l}" for l in LABELS]].sum(axis=1) > 0
    report["dropped_no_label"] = int((~has_label).sum())
    df = df[has_label].reset_index(drop=True)

    # patient-level label matrix (union over the patient's eyes)
    ycols = [f"y_{l}" for l in LABELS]
    pat = df.groupby("patient_id")[ycols].max()
    pids = pat.index.to_numpy()
    Y = pat.to_numpy().astype(int)

    # 70/15/15 via two iterative-stratified splits
    first = MultilabelStratifiedShuffleSplit(
        n_splits=1, test_size=args.val + args.test, random_state=args.seed)
    tr_idx, tmp_idx = next(first.split(np.zeros(len(pids)), Y))
    second = MultilabelStratifiedShuffleSplit(
        n_splits=1, test_size=args.test / (args.val + args.test), random_state=args.seed)
    va_rel, te_rel = next(second.split(np.zeros(len(tmp_idx)), Y[tmp_idx]))
    va_idx, te_idx = tmp_idx[va_rel], tmp_idx[te_rel]

    split_of = {}
    for name, idx in (("train", tr_idx), ("val", va_idx), ("test", te_idx)):
        for pid in pids[idx]:
            split_of[pid] = name
    df["split"] = df["patient_id"].map(split_of)

    # checks
    sets = {s: set(df.loc[df["split"] == s, "patient_id"]) for s in ("train", "val", "test")}
    assert not (sets["train"] & sets["val"]) and not (sets["train"] & sets["test"]) \
        and not (sets["val"] & sets["test"]), "patient overlap between splits"

    # gate label and output
    df["abnormal"] = 1 - df["y_N"]
    keep = ["patient_id", "eye", "filename", "path", "split", "abnormal", "keywords"] + ycols
    for s in ("train", "val", "test"):
        part = df.loc[df["split"] == s, keep]
        part.to_csv(out / f"{s}.csv", index=False)
        report[s] = {
            "images": int(len(part)),
            "patients": int(part["patient_id"].nunique()),
            "label_prevalence": {l: round(float(part[f"y_{l}"].mean()), 4) for l in LABELS},
        }

    report["label_mode"] = args.label_mode
    report["seed"] = args.seed
    report["conflicts_normal_and_disease_same_eye"] = int(
        ((df["y_N"] == 1) & (df[[f"y_{l}" for l in LABELS if l != "N"]].sum(axis=1) > 0)).sum())
    with open(out / "split_report.json", "w") as f:
        json.dump(report, f, indent=2)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
