#!/usr/bin/env python
"""Crop the black border, pad to a square and resize every image once, so training reads
small cached files. Adds a `cache_path` column to the split CSVs.

  python 03_cache_images.py --splits splits --out cache --res 512
"""
import argparse
from pathlib import Path

import pandas as pd
from PIL import Image

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from retina.datasets import crop_black_border  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--splits", default="splits")
    ap.add_argument("--out", default="cache")
    ap.add_argument("--res", type=int, default=512)
    ap.add_argument("--quality", type=int, default=95)
    a = ap.parse_args()
    out = Path(a.out) / f"r{a.res}"
    out.mkdir(parents=True, exist_ok=True)
    for s in ("train", "val", "test"):
        p = Path(a.splits) / f"{s}.csv"
        if not p.exists():
            continue
        df = pd.read_csv(p)
        cps = []
        for path, fn in zip(df["path"], df["filename"]):
            dst = out / (Path(fn).stem + ".jpg")
            if not dst.exists():
                img = crop_black_border(Image.open(path).convert("RGB"))
                img.resize((a.res, a.res), Image.LANCZOS).save(dst, quality=a.quality)
            cps.append(str(dst))
        df["cache_path"] = cps
        df.to_csv(p, index=False)
        print(f"{s}: cached {len(df)} images -> {out}")


if __name__ == "__main__":
    main()
