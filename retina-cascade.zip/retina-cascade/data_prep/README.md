# retina-cascade: data preparation (Step 3, part 1)

Two scripts: audit your ODIR-5K download, then build patient-level splits.

## Install

```
pip install pandas numpy pillow openpyxl iterative-stratification
```

## 1. Audit

```
python 01_audit_odir.py --ann "<path to ODIR annotation .xlsx or full_df.csv>" \
                        --img_dir "<folder that contains the fundus images>" \
                        --out audit
```

Outputs in `audit/`: `eye_table.csv`, `keyword_vocab.csv`, `duplicates.csv`, `audit_summary.json`.

Please send back `audit_summary.json` and the top 60 lines of `keyword_vocab.csv`. They answer
the open choices in the pipeline document:

- Does the keyword-derived eye-level labelling agree with the patient-level labels
  (`keyword_labels_subset_of_patient_labels`, `patients_where_eye_union_equals_patient_labels`)?
- Which keywords land in Others, and which are quality problems?
- How many images are missing, duplicated or cross-patient duplicates?
- Is your copy the 7,000-image original or the 6,392-image version?

## 2. Splits (after reviewing the audit)

```
python 02_make_splits.py --eye_table audit/eye_table.csv --out splits \
       --label_mode eye --seed 42 --drop_missing --drop_cross_patient_dups
```

Add `--drop_quality` only after you have checked `QUALITY_TOKENS` in `odir_labels.py`
against `keyword_vocab.csv`. Use `--label_mode patient` for the patient-level label variant.

Outputs in `splits/`: `train.csv`, `val.csv`, `test.csv`, `split_report.json`.
Both eyes of a patient always share a split; stratification is iterative on the 8-label
patient vector; seed 42; 70/15/15.

## Notes

- `KEYWORD_RULES` in `odir_labels.py` is a first draft. Refine it from `keyword_vocab.csv`
  before the final split, then re-run both scripts so every experiment uses the same files.
- The scripts were written without access to your data, so run the audit first and read its
  summary before trusting the splits.
