#!/usr/bin/env python
"""Audit an ODIR-5K download.

Reads the annotation file (xlsx or csv, original or Kaggle full_df style) and
the image folder, then writes into --out:
  eye_table.csv         one row per eye image with labels, paths and image stats
  keyword_vocab.csv     every diagnostic keyword with counts
  duplicates.csv        exact and near-duplicate image pairs (dHash)
  audit_summary.json    headline numbers to review before splitting

Usage:
  python 01_audit_odir.py --ann path/to/annotations.xlsx --img_dir path/to/images --out audit
"""
import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image

from odir_labels import (
    DISEASES,
    LABELS,
    eye_labels_from_keywords,
    is_quality_token,
    split_keywords,
)

IMG_EXT = {".jpg", ".jpeg", ".png", ".tif", ".tiff"}
POP = np.array([bin(i).count("1") for i in range(256)], dtype=np.uint8)


def load_annotations(path):
    p = Path(path)
    if p.suffix.lower() in (".xlsx", ".xls"):
        df = pd.read_excel(p)
    else:
        df = pd.read_csv(p)
    df.columns = [str(c).strip() for c in df.columns]
    return df


def to_eye_table(df):
    missing = [c for c in ["ID", "Left-Fundus", "Right-Fundus",
                           "Left-Diagnostic Keywords", "Right-Diagnostic Keywords"]
               if c not in df.columns]
    if missing:
        raise SystemExit(f"Annotation file is missing columns: {missing}\n"
                         f"Columns found: {list(df.columns)}")
    if not all(l in df.columns for l in LABELS):
        raise SystemExit("Patient-level label columns N,D,G,C,A,H,M,O not found.")

    rows = []

    def add(r, eye, fn):
        kw = r["Left-Diagnostic Keywords"] if eye == "left" else r["Right-Diagnostic Keywords"]
        rows.append({
            "patient_id": r["ID"],
            "eye": eye,
            "filename": str(fn),
            "keywords": "" if pd.isna(kw) else str(kw),
            **{f"patient_{l}": int(r[l]) for l in LABELS},
        })

    if "filename" in df.columns:  # Kaggle full_df style: one row per image
        for _, r in df.iterrows():
            fn = str(r["filename"])
            if fn == str(r["Left-Fundus"]):
                add(r, "left", fn)
            elif fn == str(r["Right-Fundus"]):
                add(r, "right", fn)
            else:
                add(r, "left", fn)
                rows[-1]["eye"] = "unknown"
    else:  # original layout: one row per patient
        for _, r in df.iterrows():
            for eye, col in (("left", "Left-Fundus"), ("right", "Right-Fundus")):
                if pd.notna(r[col]):
                    add(r, eye, r[col])
    return pd.DataFrame(rows)


def index_images(img_dir):
    idx = {}
    for p in Path(img_dir).rglob("*"):
        if p.suffix.lower() in IMG_EXT:
            idx.setdefault(p.name, p)
    return idx


def md5_of(path, chunk=1 << 20):
    h = hashlib.md5()
    with open(path, "rb") as f:
        while True:
            b = f.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def image_stats(path):
    """Return width, height, mean brightness, blur score and a 64-bit dHash."""
    out = {"width": None, "height": None, "brightness": None,
           "blur_lapvar": None, "dhash": None}
    try:
        with Image.open(path) as im:
            out["width"], out["height"] = im.size
            im.draft("L", (512, 512))
            g = im.convert("L")
            arr = np.asarray(g, dtype=np.float32)
            mask = arr > 10  # ignore black border
            out["brightness"] = float(arr[mask].mean()) if mask.any() else 0.0
            # Laplacian variance as a blur proxy (no OpenCV needed)
            lap = (-4 * arr[1:-1, 1:-1] + arr[:-2, 1:-1] + arr[2:, 1:-1]
                   + arr[1:-1, :-2] + arr[1:-1, 2:])
            out["blur_lapvar"] = float(lap.var())
            small = np.asarray(g.resize((9, 8), Image.BILINEAR), dtype=np.int16)
            bits = (small[:, 1:] > small[:, :-1]).flatten()
            out["dhash"] = int("".join("1" if b else "0" for b in bits), 2)
    except Exception as e:  # corrupt file
        out["error"] = str(e)
    return out


def near_duplicate_pairs(hashes, max_dist=4, chunk=256):
    n = len(hashes)
    h = np.array(hashes, dtype=np.uint64)
    pairs = []
    for i in range(0, n, chunk):
        blk = h[i:i + chunk]
        x = np.bitwise_xor(blk[:, None], h[None, :])
        dist = POP[x.view(np.uint8).reshape(x.shape + (8,))].sum(-1)
        ii, jj = np.where(dist <= max_dist)
        for a, b in zip(ii, jj):
            gi = i + a
            if gi < b:
                pairs.append((gi, int(b), int(dist[a, b])))
    return pairs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ann", required=True)
    ap.add_argument("--img_dir", required=True)
    ap.add_argument("--out", default="audit")
    ap.add_argument("--near_dist", type=int, default=4)
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    df = load_annotations(args.ann)
    eyes = to_eye_table(df)
    index = index_images(args.img_dir)

    eyes["path"] = eyes["filename"].map(lambda f: str(index[f]) if f in index else "")
    eyes["file_exists"] = eyes["path"] != ""

    stats = []
    for p in eyes["path"]:
        if p:
            s = image_stats(p)
            s["md5"] = md5_of(p)
        else:
            s = {"width": None, "height": None, "brightness": None,
                 "blur_lapvar": None, "dhash": None, "md5": None}
        stats.append(s)
    st = pd.DataFrame(stats)
    eyes = pd.concat([eyes.reset_index(drop=True), st], axis=1)

    # keyword-derived eye labels
    for l in LABELS:
        eyes[f"eye_{l}"] = 0
    eyes["has_quality_token"] = False
    for i, kw in enumerate(eyes["keywords"]):
        for l in eye_labels_from_keywords(kw):
            eyes.at[i, f"eye_{l}"] = 1
        eyes.at[i, "has_quality_token"] = any(is_quality_token(t) for t in split_keywords(kw))

    # vocabulary
    vocab = Counter(t for kw in eyes["keywords"] for t in split_keywords(kw))
    pd.DataFrame(vocab.most_common(), columns=["keyword", "count"]).to_csv(
        out / "keyword_vocab.csv", index=False)

    # agreement between keyword-derived eye labels and patient-level labels
    sub_ok = 0
    for _, r in eyes.iterrows():
        ev = {l for l in LABELS if r[f"eye_{l}"]}
        pv = {l for l in LABELS if r[f"patient_{l}"]}
        if ev and ev <= pv:
            sub_ok += 1
    n_eyes_with_labels = int((eyes[[f"eye_{l}" for l in LABELS]].sum(axis=1) > 0).sum())

    union_ok = 0
    n_pat = 0
    for pid, g in eyes.groupby("patient_id"):
        n_pat += 1
        ev = {l for l in LABELS if g[f"eye_{l}"].max() == 1}
        pv = {l for l in LABELS if g[f"patient_{l}"].max() == 1}
        union_ok += int(ev == pv)

    # duplicates
    valid = eyes[eyes["dhash"].notna()].reset_index()
    dup_rows = []
    if len(valid):
        by_md5 = valid.groupby("md5")["index"].apply(list)
        for _, idxs in by_md5.items():
            if len(idxs) > 1:
                for a in range(len(idxs)):
                    for b in range(a + 1, len(idxs)):
                        dup_rows.append((idxs[a], idxs[b], 0, "exact"))
        pairs = near_duplicate_pairs(valid["dhash"].tolist(), args.near_dist)
        seen = {(a, b) for a, b, _, _ in dup_rows}
        for a, b, d in pairs:
            ia, ib = int(valid.loc[a, "index"]), int(valid.loc[b, "index"])
            if (ia, ib) not in seen and (ib, ia) not in seen:
                dup_rows.append((ia, ib, d, "near"))
    dups = pd.DataFrame(dup_rows, columns=["row_a", "row_b", "hamming", "kind"])
    if len(dups):
        dups["file_a"] = dups["row_a"].map(eyes["filename"])
        dups["file_b"] = dups["row_b"].map(eyes["filename"])
        dups["patient_a"] = dups["row_a"].map(eyes["patient_id"])
        dups["patient_b"] = dups["row_b"].map(eyes["patient_id"])
        dups["cross_patient"] = dups["patient_a"] != dups["patient_b"]
    dups.to_csv(out / "duplicates.csv", index=False)

    eyes.to_csv(out / "eye_table.csv", index=False)

    summary = {
        "annotation_rows": int(len(df)),
        "annotation_layout": "one row per image" if "filename" in df.columns else "one row per patient",
        "n_patients": int(eyes["patient_id"].nunique()),
        "n_eye_rows": int(len(eyes)),
        "files_found": int(eyes["file_exists"].sum()),
        "files_missing": int((~eyes["file_exists"]).sum()),
        "patient_label_counts": {l: int(eyes.drop_duplicates("patient_id")[f"patient_{l}"].sum())
                                 for l in LABELS},
        "eye_label_counts_from_keywords": {l: int(eyes[f"eye_{l}"].sum()) for l in LABELS},
        "eyes_with_no_derived_label": int(len(eyes) - n_eyes_with_labels),
        "eyes_with_quality_token": int(eyes["has_quality_token"].sum()),
        "keyword_labels_subset_of_patient_labels": f"{sub_ok}/{n_eyes_with_labels}",
        "patients_where_eye_union_equals_patient_labels": f"{union_ok}/{n_pat}",
        "image_sizes_top5": Counter(
            f"{int(w)}x{int(h)}" for w, h in zip(eyes["width"].dropna(), eyes["height"].dropna())
        ).most_common(5),
        "exact_duplicate_pairs": int((dups["kind"] == "exact").sum()) if len(dups) else 0,
        "near_duplicate_pairs": int((dups["kind"] == "near").sum()) if len(dups) else 0,
        "cross_patient_duplicate_pairs": int(dups["cross_patient"].sum()) if len(dups) else 0,
        "blur_lapvar_percentiles": (
            {str(q): float(np.nanpercentile(eyes["blur_lapvar"].astype(float), q))
             for q in (1, 5, 25, 50)} if eyes["blur_lapvar"].notna().any() else {}),
    }
    with open(out / "audit_summary.json", "w") as f:
        json.dump(summary, f, indent=2)
    print(json.dumps(summary, indent=2))
    print(f"\nWrote files to {out.resolve()}")


if __name__ == "__main__":
    main()
