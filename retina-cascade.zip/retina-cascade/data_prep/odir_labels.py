"""Shared ODIR-5K label definitions.

ODIR classes: N (normal), D (diabetes/DR), G (glaucoma), C (cataract),
A (AMD), H (hypertension), M (myopia), O (others).

The keyword mapping below is a first draft. The audit script reports how well
it agrees with the patient-level labels and lists every keyword in your copy,
so refine KEYWORD_RULES after reading keyword_vocab.csv.
"""
import re

LABELS = ["N", "D", "G", "C", "A", "H", "M", "O"]
DISEASES = ["D", "G", "C", "A", "H", "M", "O"]

LABEL_NAMES = {
    "N": "Normal",
    "D": "Diabetes/DR",
    "G": "Glaucoma",
    "C": "Cataract",
    "A": "AMD",
    "H": "Hypertension",
    "M": "Myopia",
    "O": "Others",
}

# Keywords that usually signal an unusable or non-fundus image. These are
# candidates for the quality filter (the thesis removed severe artefacts,
# misalignment, blur and poor illumination). Review before enabling.
QUALITY_TOKENS = (
    "low image quality",
    "image offset",
    "no fundus image",
    "anterior segment image",
    "optic disk photographically invisible",
    "lens dust",
)

# Ordered (label, substrings). A keyword token can trigger several labels.
KEYWORD_RULES = [
    ("N", ("normal fundus",)),
    ("H", ("hypertensive",)),
    ("D", ("diabetic", "nonproliferative", "proliferative retinopathy")),
    ("G", ("glaucoma",)),
    ("C", ("cataract",)),
    ("A", ("macular degeneration",)),
    ("M", ("myopia", "myopic")),
]


def split_keywords(text):
    """Split an ODIR keyword cell on ASCII and full-width separators."""
    if text is None:
        return []
    s = str(text)
    if s.lower() == "nan":
        return []
    parts = re.split(r"[,\uff0c;\uff1b]", s)
    return [p.strip().lower() for p in parts if p.strip()]


def is_quality_token(token):
    return any(q in token for q in QUALITY_TOKENS)


def eye_labels_from_keywords(text):
    """Map one eye's diagnostic keywords to a set of ODIR labels.

    Tokens that match no rule and are not quality tokens fall into O.
    Returns an empty set if there are no usable keywords.
    """
    labels = set()
    for tok in split_keywords(text):
        matched = False
        for label, subs in KEYWORD_RULES:
            if any(s in tok for s in subs):
                labels.add(label)
                matched = True
        if not matched and not is_quality_token(tok):
            labels.add("O")
    return labels
